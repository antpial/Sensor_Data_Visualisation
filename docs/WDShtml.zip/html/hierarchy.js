var hierarchy =
[
    [ "ChartConfig", "structChartConfig.html", null ],
    [ "ParsedPacket", "structParsedPacket.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "classMainWindow.html", null ]
    ] ],
    [ "QObject", null, [
      [ "SerialManager", "classSerialManager.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "ChartWindow", "classChartWindow.html", null ]
    ] ],
    [ "SensorTile", "structSensorTile.html", null ]
];