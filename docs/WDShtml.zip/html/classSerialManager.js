var classSerialManager =
[
    [ "SerialManager", "classSerialManager.html#aa2d090c2f7dc822a3fb1f3ac432abd0d", null ],
    [ "newPacketReceived", "classSerialManager.html#a9a87300a5ea23e50817b47545534e55f", null ],
    [ "parseSerialLine", "classSerialManager.html#a43f9af28ef02b9e1a4eed48a0a1d7e7e", null ],
    [ "readData", "classSerialManager.html#ab9f933dca0b5d7a302acc702ef395706", null ],
    [ "serialError", "classSerialManager.html#acf8595e4fcee2d061daea8e63517c89f", null ],
    [ "start", "classSerialManager.html#a97cb7430b2decec7805fde39590ed7fa", null ],
    [ "serial", "classSerialManager.html#a5b4e9ddd74bb9faff2ec2088c59bcf9d", null ]
];