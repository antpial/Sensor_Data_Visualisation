var structParsedPacket =
[
    [ "hasPosition", "structParsedPacket.html#a8b780ebe2dea38bfbf4daa3f17a50493", null ],
    [ "latitude", "structParsedPacket.html#ab39507c102d3c4cadf87af36b9b34203", null ],
    [ "log", "structParsedPacket.html#a21c17f7e156918b39f9b4f52edaa34fc", null ],
    [ "longitude", "structParsedPacket.html#a3094b3a650084273b23890a521ce4783", null ],
    [ "sensors", "structParsedPacket.html#a5717e3804d9be81e2bac5161e4c17f2c", null ]
];