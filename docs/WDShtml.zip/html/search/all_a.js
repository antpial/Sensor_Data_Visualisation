var searchData=
[
  ['namelabel_0',['nameLabel',['../structSensorTile.html#a1fa553fd51f55be7be9ac6758e71877a',1,'SensorTile']]],
  ['newpacketreceived_1',['newPacketReceived',['../classSerialManager.html#a9a87300a5ea23e50817b47545534e55f',1,'SerialManager']]],
  ['num_5fof_5fsamples_2',['NUM_OF_SAMPLES',['../chartwindow_8cpp.html#add28519412f37ec4551e30e2aa3cc130',1,'chartwindow.cpp']]]
];
