var searchData=
[
  ['newpacketreceived_0',['newPacketReceived',['../classSerialManager.html#a9a87300a5ea23e50817b47545534e55f',1,'SerialManager']]]
];
