var searchData=
[
  ['namelabel_0',['nameLabel',['../structSensorTile.html#a1fa553fd51f55be7be9ac6758e71877a',1,'SensorTile']]]
];
