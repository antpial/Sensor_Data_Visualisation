var searchData=
[
  ['chartwindow_0',['chartWindow',['../classMainWindow.html#ae7b5edf93b98f6a1f0db64564a69cc96',1,'MainWindow']]],
  ['color_1',['color',['../structChartConfig.html#a59f7662dc6929f9a301f8e84f3c996dc',1,'ChartConfig']]]
];
