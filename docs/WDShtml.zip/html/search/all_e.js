var searchData=
[
  ['translator_0',['translator',['../classMainWindow.html#a8e829b3590ccdeeada42625415afc6f3',1,'MainWindow']]]
];
