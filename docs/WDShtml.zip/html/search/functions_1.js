var searchData=
[
  ['generate_5fcircular_5fcoordinates_0',['generate_circular_coordinates',['../namespacesender.html#a4f9705a1286d85955ffd896aa6261edb',1,'sender']]]
];
