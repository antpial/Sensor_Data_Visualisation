var searchData=
[
  ['num_5fof_5fsamples_0',['NUM_OF_SAMPLES',['../chartwindow_8cpp.html#add28519412f37ec4551e30e2aa3cc130',1,'chartwindow.cpp']]]
];
