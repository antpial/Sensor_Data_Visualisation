var searchData=
[
  ['handlenewpacket_0',['handleNewPacket',['../classMainWindow.html#a2d8c660a89cbff3f408e33110c1c2c61',1,'MainWindow']]],
  ['handleserialerror_1',['handleSerialError',['../classMainWindow.html#a064b13fe8d8c2c4471dec0c44a4b0a6b',1,'MainWindow']]]
];
