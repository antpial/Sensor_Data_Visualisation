var structChartConfig =
[
    [ "color", "structChartConfig.html#a59f7662dc6929f9a301f8e84f3c996dc", null ],
    [ "sensorName", "structChartConfig.html#ad39334b0e85542174c7602e036edc11b", null ],
    [ "unitY", "structChartConfig.html#aacf4fa7d81792040525b3ab7e31f17b5", null ],
    [ "yRange", "structChartConfig.html#a4d3727dd27e5f5bbd216d29383d0d42e", null ]
];