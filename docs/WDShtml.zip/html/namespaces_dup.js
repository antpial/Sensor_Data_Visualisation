var namespaces_dup =
[
    [ "sender", "namespacesender.html", [
      [ "generate_circular_coordinates", "namespacesender.html#a4f9705a1286d85955ffd896aa6261edb", null ],
      [ "angle", "namespacesender.html#ae1cc33e852a1a7d42321e84cbe266ec4", null ],
      [ "angular_speed_deg_per_sec", "namespacesender.html#ae14be42f80757e2ac7fbba7c1da9dd50", null ],
      [ "BAUD_RATE", "namespacesender.html#ae49ce1bd4e9992753ee9b4eb391bd381", null ],
      [ "EARTH_RADIUS", "namespacesender.html#ae062f7af50dedac7843a9f1f44f47727", null ],
      [ "gps_coords", "namespacesender.html#a8139e479d3f16bc95ef5d253300da965", null ],
      [ "i", "namespacesender.html#a167ecc363ec220fca8586feb9a0c96b1", null ],
      [ "lat", "namespacesender.html#aa3b05347cd8bf4181ad39be59ae51c62", null ],
      [ "lon", "namespacesender.html#a73899320007cf34f0d3affedc769da46", null ],
      [ "message", "namespacesender.html#ade590ab6f9253e036d94151cb25acee7", null ],
      [ "PORT", "namespacesender.html#a9f37da13fe4520d69f6faeb05d26c78a", null ],
      [ "radius", "namespacesender.html#a5325b9900ae4e312e1c897f126ba0814", null ],
      [ "SENSOR_RANGES", "namespacesender.html#a2a79b48310f28dddc55624fe44dc90ab", null ],
      [ "sensor_values", "namespacesender.html#a7b6778339682ab9a9b3bd1bd4d397ef3", null ],
      [ "ser", "namespacesender.html#a1ae8f95a1098e31638cdc47980f0d1d4", null ],
      [ "start_lat", "namespacesender.html#a660ff5f39d1a59b1b3d18a36edc18019", null ],
      [ "start_lon", "namespacesender.html#abc13dc3fb9c99d9925f270acaad69dbc", null ],
      [ "val", "namespacesender.html#a3d12c2434abf97cd2e17b81d80816347", null ]
    ] ],
    [ "Ui", "namespaceUi.html", null ]
];