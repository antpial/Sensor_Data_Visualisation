var structSensorTile =
[
    [ "frame", "structSensorTile.html#a252b6703828d886c7ffca26ea053b896", null ],
    [ "nameLabel", "structSensorTile.html#a1fa553fd51f55be7be9ac6758e71877a", null ],
    [ "valueLabel", "structSensorTile.html#ada36f7d86cb0805a55f9f30efab2321d", null ]
];