var mainwindow_8cpp =
[
    [ "CRITICAL_DEPTH", "mainwindow_8cpp.html#aa8a4beea0b619696e5be70f0f7cbcee4", null ],
    [ "PORT_PATH", "mainwindow_8cpp.html#a8ecce89454d01137c9ec050f99df0585", null ]
];