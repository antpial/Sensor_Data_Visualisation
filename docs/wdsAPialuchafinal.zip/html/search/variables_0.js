var searchData=
[
  ['angle_0',['angle',['../namespacesender.html#ae1cc33e852a1a7d42321e84cbe266ec4',1,'sender']]],
  ['angular_5fspeed_5fdeg_5fper_5fsec_1',['angular_speed_deg_per_sec',['../namespacesender.html#ae14be42f80757e2ac7fbba7c1da9dd50',1,'sender']]]
];
