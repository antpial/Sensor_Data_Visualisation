var searchData=
[
  ['sender_0',['sender',['../namespacesender.html',1,'']]]
];
