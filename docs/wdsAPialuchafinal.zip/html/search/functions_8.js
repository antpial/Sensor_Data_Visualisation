var searchData=
[
  ['readdata_0',['readData',['../classSerialManager.html#ab9f933dca0b5d7a302acc702ef395706',1,'SerialManager']]],
  ['resizeevent_1',['resizeEvent',['../classMainWindow.html#aad75236c74a5c340c3e18749a9b5eb4f',1,'MainWindow']]],
  ['retranslateui_2',['retranslateUi',['../classChartWindow.html#aefc5d504858c6f891f507fd9d9cdf6a3',1,'ChartWindow']]]
];
