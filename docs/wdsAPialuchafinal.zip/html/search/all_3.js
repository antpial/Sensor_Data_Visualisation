var searchData=
[
  ['earth_5fradius_0',['EARTH_RADIUS',['../namespacesender.html#ae062f7af50dedac7843a9f1f44f47727',1,'sender']]]
];
