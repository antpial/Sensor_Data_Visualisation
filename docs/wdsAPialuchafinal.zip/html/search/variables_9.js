var searchData=
[
  ['mapready_0',['mapReady',['../classMainWindow.html#afd14383d1d27c426e0cf1df5bf20cb16',1,'MainWindow']]],
  ['message_1',['message',['../namespacesender.html#ade590ab6f9253e036d94151cb25acee7',1,'sender']]]
];
