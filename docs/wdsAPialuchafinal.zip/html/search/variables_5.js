var searchData=
[
  ['gps_5fcoords_0',['gps_coords',['../namespacesender.html#a8139e479d3f16bc95ef5d253300da965',1,'sender']]]
];
