var searchData=
[
  ['frame_0',['frame',['../structSensorTile.html#a252b6703828d886c7ffca26ea053b896',1,'SensorTile']]]
];
