var searchData=
[
  ['generate_5fcircular_5fcoordinates_0',['generate_circular_coordinates',['../namespacesender.html#a4f9705a1286d85955ffd896aa6261edb',1,'sender']]],
  ['gps_5fcoords_1',['gps_coords',['../namespacesender.html#a8139e479d3f16bc95ef5d253300da965',1,'sender']]]
];
