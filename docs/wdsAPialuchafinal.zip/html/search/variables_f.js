var searchData=
[
  ['ui_0',['ui',['../classChartWindow.html#aa5b7848a04ff1432fe842398ab54dae9',1,'ChartWindow::ui'],['../classMainWindow.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui']]],
  ['unity_1',['unitY',['../structChartConfig.html#aacf4fa7d81792040525b3ab7e31f17b5',1,'ChartConfig']]]
];
