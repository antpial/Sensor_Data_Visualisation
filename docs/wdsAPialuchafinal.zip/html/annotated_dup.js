var annotated_dup =
[
    [ "ChartConfig", "structChartConfig.html", "structChartConfig" ],
    [ "ChartWindow", "classChartWindow.html", "classChartWindow" ],
    [ "MainWindow", "classMainWindow.html", "classMainWindow" ],
    [ "ParsedPacket", "structParsedPacket.html", "structParsedPacket" ],
    [ "SensorTile", "structSensorTile.html", "structSensorTile" ],
    [ "SerialManager", "classSerialManager.html", "classSerialManager" ]
];