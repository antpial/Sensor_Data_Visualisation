var files_dup =
[
    [ "chartwindow.cpp", "chartwindow_8cpp.html", "chartwindow_8cpp" ],
    [ "chartwindow.h", "chartwindow_8h.html", "chartwindow_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", "mainwindow_8cpp" ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "parsedpacket.h", "parsedpacket_8h.html", "parsedpacket_8h" ],
    [ "sender.py", "sender_8py.html", "sender_8py" ],
    [ "serialmanager.cpp", "serialmanager_8cpp.html", null ],
    [ "serialmanager.h", "serialmanager_8h.html", "serialmanager_8h" ]
];